# inzynieria-oprogramowania
Stronia internetowa przedstawiająca księgarnię internetową. Została ona zrealizowana na potrzeby przedmiotu: "Inżynieria oprogramowania"
